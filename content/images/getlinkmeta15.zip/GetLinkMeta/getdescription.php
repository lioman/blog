<?php

$meta_data= get_meta_tags($_GET['linkurl']);
$desc= $meta_data['description'];
?>
<form>
<input type="text" name="getURL_description" value=" <?php echo $desc; ?>" id="getURL_description">

   </form>
<input type="button" onclick="javascript: parent.document.getElementById('link_description').value = document.getElementById('getURL_description').value;" class="button" value="Submit">

