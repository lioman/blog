=== 2 Click Social Media Buttons ===
Contributors: ppfeufer
Donate link:
Tags: twitter, facebook, googleplus, button
Requires at least: 3.0.1
Tested up to: 3.2
Stable tag: 0.3

Fügt die Buttons für Facebook-Like (Empfehlen), Twitter und Googleplus dem deutschen Datenschutz entsprechend in euer WordPress ein.

== Description ==

Fügt die Buttons für Facebook-Like (Empfehlen), Twitter und Googleplus dem deutschen Datenschutz entsprechend in euer WordPress ein.
Dies wird leider durch immer verwirrendere Datenschutzbestimmungen notwendig. Das Plugin ist eine WordPress-Adaption der Lösung von heise.de wie in ihrem Artikel <a href="http://www.heise.de/ct/artikel/2-Klicks-fuer-mehr-Datenschutz-1333879.html">2 Klicks für mehr Datenschutz</a> beschrieben.
Bisher werden die Buttons einfach in den Einzelartikeln und -seiten unter dem Artikel eingebunden. Einige Einstellungsmöglichkeiten sind noch in Planung.

**Features**

* Einfache Installation.
* Einstellungen speicherbar.

== Installation ==

Nutze dafür einfach dein Dashboard

**Installation via Wordpress**

1. Gehe ins Menü 'Plugins' -> 'Install' und suche nach '2 Click Social Media Buttons'
1. Klicke hier auf 'install'

**Manuelle Installation**

1. Lade das Verzeichnis `2-click-socialmedia-buttons` in Dein `/wp-content/plugins/`-Verzeichnis Deines WordPres.
1. Aktiviere das Plugin.

== Screenshots ==

1. Buttons unter dem Text.
2. Hinweis bei Mouseover.
3. Einstellungsmenü der Buttons.


== Changelog ==
= 0.3 =
* (05. 09. 2011)
* Fix: CSS angepasst um ungewolltes Padding zu verhindern.

= 0.2 =
* (05. 09. 2011)
* Fix: Falsch aufgerufenen Hook entfernt.

= 0.1 =
* (04. 09. 2011)
* Initial Release

== Frequently Asked Questions ==

Bisher keine.

== Upgrade Notice ==

Hier ist nichts zu beachten.