<?php
/**
 * @package WordPress
 * @subpackage Yoko
 */
?>

</div><!-- end wrap -->

	<footer id="colophon" class="clearfix">
Copyright - Some Rights Reserved - <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/de/"><img alt="Creative Commons License" style="border-width:0" src="/wp-content/uploads/badge/commons.png" width="88" height="31" /></a> <br> <a rel="author" href"https://plus.google.com/109360831420720419136">Me on Google</a><a href="/_falle_/index.php"><img border="0" src="/_falle_/images/fall01.jpg" width="30" height="29" alt=" "/></a> |
<a href="http://blogpingr.de" title="BlogPingR.de: Blog Ping-Dienst, Blogmonitor"><img src="/wp-content/uploads/badge/blogpingr.png" alt="BlogPingR.de - Blog Ping-Dienst, Blogmonitor" width="80" height="15" border="0" /><a href="http://www.blogcatalog.com/directory/internet" title="Internet Blogs - BlogCatalog Blog Directory"><img src="/wp-content/uploads/badge/blogcatalog5.png" width="80" height="15" alt="Internet Blogs - BlogCatalog Blog Directory" style="border: 0;" /></a> <a href="http://blogalm.de/" title="Blogverzeichnis"><img src="/wp-content/uploads/badge/blogalm_button_rund.gif" width="80" height="15" border="0" alt="Blogverzeichnis" /></a><a href="/wp-content/uploads/badge/blog_button9.gif" style="border:0px;" alt="Bloggeramt.de" /></a><!--Code--><a href="http://www.bloggernetz.de" title="Bloggernetz - der deutschsprachige Pingdienst"><img src="/wp-content/uploads/badge/bloggernetz_80_15.jpg" width="80" height="15" alt="Bloggernetz - der deutschsprachige Pingdienst" /></a><!--/Code--><a href="http://www.wikio.de/blogs/top"><img src="http://external.wikio.de/blogs/top/getrank?url=http://www.lioman.de"  width="90" height="40" style="border: none; " alt="Wikio - Top Blog"/></a>
		<p>Proudly powered by <a href="http://wordpress.org/">WordPress</a><span class="sep"> | </span><?php printf( __( 'Theme: %1$s by %2$s', 'yoko' ), 'Yoko', '<a href="http://www.elmastudio.de/wordpress-themes/">Elmastudio</a>' ); ?></p>
		<a href="#page" class="top"><?php _e( 'Top', 'yoko' ); ?></a>
	</footer><!-- end colophon -->
	
</div><!-- end page -->
<?php wp_footer(); ?>
<script language="javascript" src="/wp-includes/js/jquery/jquery.tweet.js" type="text/javascript"></script> 


<script type="text/javascript">
  window.___gcfg = {lang: 'de'};

    jQuery(function($){
        $(".tweeti").tweeti({
            username: "lioman",
            avatar_size: 24,
            count: 4,
            auto_join_text_default: "we said,",
            auto_join_text_ed: "ich",
            auto_join_text_ing: "ich war",
            auto_join_text_reply: "ich antwortete auf",
            auto_join_text_url: "we were checking out",
            loading_text: "lade..."
        });
    });

	
</script>
</body>
</html>
