<?php
/*
Plugin Name: Get Link Meta
Plugin URI: http://wordpress.org/extend/plugins/getlinkdescription
Description: Get Description from site-meta-data for links
Author: Elias Kirchgässner
Version: 0.1.1
License: GPL
Author URI: http://www.lioman.de
Update Server: http://wordpress.org/.. (Link zum Update-Server, wo das Plugin liegt.)
Min WP Version: 1.5
Max WP Version: 3.2.1

?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/pathto/yourscript.js"></script>
<script>
document.forms[link_description].text.value = <?php echo $desc ?>
</script>


<?php
*/
//Rendere Box
global $wp_version;
if (version_compare($wp_version,"3.0","<")) /*provides the current WordPress version in standard format*/
{
 add_action('admin_init', 'addMetaBox', 1); /*for versions < 3.0*/
}
else
{
 add_action('add_meta_boxes', 'addMetaBox'); /*for versions >=3.0*/
}
 
function addMetaBox()
{
$meta_data= get_meta_tags($_GET["linkurl"]);
$description= $meta_data['description'];
echo $description
 add_meta_box( 'boxId', __( 'Get Link Meta', 'myplugin_textdomain' ), 'renderHtml', 'link', 'normal', 'high', array('showbutton'=>true) );
}
 
function renderHtml($post, $params)
{
 $myParams = $params['args'];
 
 if($myParams['showbutton'])
 {
?>
<div>
Die URL ist <?php echo $_GET["linkurl"] ?></br>
Dies ist die Beschreibung: <?php echo $description; ?>

</div>
 <input type="button" class="button" value="Get Link Meta" onload="jsGetDescrition" name="getlinkmeta" id="getlinkmeta"  />
 

<?php
 }
 
 // Use nonce for verification
 wp_nonce_field( plugin_basename(__FILE__), 'myNonce' );
}
?>
